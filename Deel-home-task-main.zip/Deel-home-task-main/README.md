# Deel - Frontend test (React + TypeScript + Vite)

Auto-complete component using React + TypeScript.

## Running the project

- `npm install`
- `npm run dev`

